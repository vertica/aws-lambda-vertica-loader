#!/bin/sh
zip -r dist/AWSLambdaVerticaLoader-1.0.0.zip *.js *.png *.py *.txt node_modules/ *.json *.md 
