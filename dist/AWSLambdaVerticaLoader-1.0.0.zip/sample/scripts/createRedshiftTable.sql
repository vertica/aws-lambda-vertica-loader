create table lambda_redshift_sample(
column_a int,
column_b int,
column_c int
);